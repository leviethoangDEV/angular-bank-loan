## Objective

- Learn how to clone a pre-trained Text-to-Speech (TTS) model from Hugging Face
- Perform inference to convert input text into spoken audio using the cloned model
- Understand basics of audio synthesis and model deployment

## Problem Statement

Text-to-Speech (TTS) technology converts written text into natural-sounding speech, enabling applications such as voice assistants, accessibility tools, and multimedia content creation. This exercise clones a pre-trained TTS model from Hugging Face and performs inference to generate audio from text.

## Installation

```bash
python -m pip install -r requirements.txt
```

**Note:** This may take a few minutes as it downloads model files (~500MB).

## Run

```bash
python tts_generator.py
```

Audio files will be generated:
- `output_audio_1_vie.wav` (Vietnamese)
- `output_audio_2_vie.wav` (Vietnamese)
- `output_audio_3_vie.wav` (Vietnamese)
- `output_audio_4_eng.wav` (English)
- `output_audio_5_eng.wav` (English)

## Approach

### Model Selection
- Uses `facebook/mms-tts-vie` - Vietnamese TTS model from Meta's Massively Multilingual Speech project
- Uses `facebook/mms-tts-eng` - English TTS model for English samples
- Pre-trained VITS (Variational Inference with adversarial learning for end-to-end Text-to-Speech) architecture
- Automatically switches models based on language

### Pipeline Steps

1. **Load Model:** Clone pre-trained TTS model from Hugging Face Hub (Vietnamese first)
2. **Load Tokenizer:** Load corresponding tokenizer for text processing
3. **Prepare Text:** 5 sample sentences (3 Vietnamese + 2 English)
4. **Switch Model:** Automatically switch to English model when needed
5. **Tokenize:** Convert text to model input format
6. **Inference:** Generate audio waveform using model
7. **Save Audio:** Export waveform to WAV file format with language suffix

### Sample Texts

**Vietnamese (3 samples):**
1. "Xin chào, đây là bài tập về AI Application Engineer"
2. "Chúng tôi đang học về Text to Speech technology"
3. "Công nghệ AI đang phát triển rất nhanh"

**English (2 samples):**
4. "Hello, this is an assignment about AI Application Engineer"
5. "We are learning about Text to Speech technology"

## Challenges & Solutions

### 1. Model Availability
- **Challenge:** Limited Vietnamese TTS models on Hugging Face
- **Solution:** Used Meta's MMS-TTS which supports 1000+ languages including Vietnamese

### 2. Audio Format Conversion
- **Challenge:** Model outputs PyTorch tensor, need standard audio format
- **Solution:** Convert to numpy array and use scipy.io.wavfile for WAV export

### 3. Dependencies
- **Challenge:** Multiple libraries required (transformers, torch, scipy)
- **Solution:** All dependencies listed in requirements.txt with specific versions

### 4. Model Size
- **Challenge:** TTS models are large (~500MB)
- **Solution:** First run downloads model, subsequent runs use cached version

## Concepts Covered

- Model cloning and loading from Hugging Face Hub
- Using Transformers TTS interface for audio synthesis
- Basic audio processing and playback in Python
- Tensor to audio file conversion
- Working with pre-trained models

## Output

- **Format:** WAV audio files (16-bit PCM)
- **Sampling Rate:** 16000 Hz (model default)
- **Duration:** ~2-5 seconds per sample
- **Quality:** Natural-sounding Vietnamese and English speech
- **Total Files:** 5 audio files (3 Vietnamese + 2 English)

## Playing Audio Files

### Windows
- Double-click WAV files (opens in Windows Media Player)
- Or use VLC, Audacity, etc.

### Python (Optional)
```python
import IPython.display as ipd
# Play Vietnamese audio
ipd.Audio("output_audio_1_vie.wav")
# Play English audio
ipd.Audio("output_audio_4_eng.wav")
```

## Model Information

**facebook/mms-tts-vie:**
- Architecture: VITS (Variational Inference TTS)
- Language: Vietnamese
- Training: Meta's Massively Multilingual Speech dataset
- License: CC-BY-NC 4.0

**facebook/mms-tts-eng:**
- Architecture: VITS (Variational Inference TTS)
- Language: English
- Training: Meta's Massively Multilingual Speech dataset
- License: CC-BY-NC 4.0

## Future Enhancements

- Support for custom text input
- More languages (MMS supports 1000+ languages)
- Multiple voice options
- Adjustable speech rate and pitch
- Real-time audio playback
- Web interface for easy access
- Batch processing for large text files
