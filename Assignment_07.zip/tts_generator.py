# tts_generator.py
# Clone and Perform Inference with Hugging Face Text-to-Speech (TTS) Model

from transformers import VitsModel, AutoTokenizer
import torch
import scipy.io.wavfile
import numpy as np

# Step 1: Model configuration
MODEL_NAME = "facebook/mms-tts-vie"  # Vietnamese TTS model

print("Text-to-Speech Generator using Hugging Face")
print("="*80)

# Step 2: Clone and load the pre-trained TTS model from Hugging Face
print("\nStep 1: Loading TTS model from Hugging Face...")
print(f"Model: {MODEL_NAME}")

try:
    model = VitsModel.from_pretrained(MODEL_NAME)
    tokenizer = AutoTokenizer.from_pretrained(MODEL_NAME)
    print("✓ Model and tokenizer loaded successfully")
except Exception as e:
    print(f"✗ Error loading model: {e}")
    print("\nTrying alternative model...")
    MODEL_NAME = "facebook/mms-tts-eng"  # Fallback to English
    model = VitsModel.from_pretrained(MODEL_NAME)
    tokenizer = AutoTokenizer.from_pretrained(MODEL_NAME)
    print(f"✓ Loaded alternative model: {MODEL_NAME}")

# Step 3: Prepare input text (5 samples - 3 Vietnamese + 2 English)
sample_texts = [
    ("vie", "Xin chào, đây là bài tập về AI Application Engineer"),
    ("vie", "Chúng tôi đang học về Text to Speech technology"),
    ("vie", "Công nghệ AI đang phát triển rất nhanh"),
    ("eng", "Hello, this is an assignment about AI Application Engineer"),
    ("eng", "We are learning about Text to Speech technology")
]

print(f"\nStep 2: Preparing {len(sample_texts)} text samples for synthesis...")

# Step 4: Generate audio for each text
print("\nStep 3: Generating audio from text...")

# Keep track of current model
current_model_lang = "vie"

for idx, (lang, text) in enumerate(sample_texts, 1):
    print(f"\n{'='*80}")
    print(f"Sample {idx}/{len(sample_texts)}")
    print(f"{'='*80}")
    print(f"Language: {lang.upper()}")
    print(f"Input text: {text}")
    
    try:
        # Switch model if language changes
        if lang != current_model_lang:
            print(f"  → Switching to {lang.upper()} model...")
            model_name_new = f"facebook/mms-tts-{lang}"
            model = VitsModel.from_pretrained(model_name_new)
            tokenizer = AutoTokenizer.from_pretrained(model_name_new)
            current_model_lang = lang
            print(f"  ✓ Model switched to: {model_name_new}")
        
        # Step 5: Tokenize the input text
        print("  → Tokenizing text...")
        inputs = tokenizer(text, return_tensors="pt")
        
        # Step 6: Perform inference to generate the waveform
        print("  → Generating audio waveform...")
        with torch.no_grad():
            output = model(**inputs).waveform
        
        # Step 7: Convert to numpy array
        audio_data = output.squeeze().cpu().numpy()
        
        # Get sampling rate from model config
        sampling_rate = model.config.sampling_rate
        
        print(f"  → Audio generated successfully")
        print(f"     Duration: {len(audio_data)/sampling_rate:.2f} seconds")
        print(f"     Sampling rate: {sampling_rate} Hz")
        
        # Step 8: Save audio to file
        output_filename = f"output_audio_{idx}_{lang}.wav"
        scipy.io.wavfile.write(output_filename, rate=sampling_rate, data=audio_data)
        print(f"  ✓ Saved to: {output_filename}")
        
    except Exception as e:
        print(f"  ✗ Error generating audio: {e}")

print("\n" + "="*80)
print("Audio Generation Complete!")
print("="*80)

# Summary
print("\nSummary:")
print(f"  Models used: facebook/mms-tts-vie, facebook/mms-tts-eng")
print(f"  Texts processed: {len(sample_texts)}")
print(f"  Vietnamese samples: 3")
print(f"  English samples: 2")
print(f"  Audio files generated:")
for i in range(1, 4):
    print(f"    - output_audio_{i}_vie.wav")
for i in range(4, 6):
    print(f"    - output_audio_{i}_eng.wav")
print("\nYou can play these files using any audio player.")

# Note about challenges
print("\n" + "="*80)
print("Challenges Faced:")
print("="*80)
print("1. Model Selection: Vietnamese TTS models are limited on Hugging Face")
print("   Solution: Used facebook/mms-tts-vie for Vietnamese support")
print("\n2. Audio Format: Need to convert tensor to numpy for saving")
print("   Solution: Used scipy.io.wavfile for WAV file export")
print("\n3. Dependencies: Requires transformers, torch, scipy")
print("   Solution: All included in requirements.txt")
