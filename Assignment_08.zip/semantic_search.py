# semantic_search.py
# Building a Semantic Search Engine with Text Embeddings for Clothing Products

import os
from openai import OpenAI
from scipy.spatial.distance import cosine

# Load environment variables
try:
    from dotenv import load_dotenv
    load_dotenv()
except ImportError:
    pass

# Setup OpenAI Client
client = OpenAI(
    base_url=os.getenv("OPENAI_BASE_URL"),
    api_key=os.getenv("OPENAI_API_KEY"),
)

# Step 1: Sample product data (clothing products)
products = [
    {
        "title": "Classic Blue Jeans",
        "short_description": "Comfortable blue denim jeans with a relaxed fit.",
        "price": 49.99,
        "category": "Jeans"
    },
    {
        "title": "Red Hoodie",
        "short_description": "Cozy red hoodie made from organic cotton.",
        "price": 39.99,
        "category": "Hoodies"
    },
    {
        "title": "Black Leather Jacket",
        "short_description": "Stylish black leather jacket with a slim fit design.",
        "price": 120.00,
        "category": "Jackets"
    },
    {
        "title": "White Cotton T-Shirt",
        "short_description": "Basic white cotton t-shirt, perfect for everyday wear.",
        "price": 15.99,
        "category": "T-Shirts"
    },
    {
        "title": "Blue Denim Jacket",
        "short_description": "Classic denim jacket in blue, great for layering.",
        "price": 65.00,
        "category": "Jackets"
    },
    {
        "title": "Gray Sweatpants",
        "short_description": "Comfortable gray sweatpants for lounging or exercise.",
        "price": 29.99,
        "category": "Pants"
    },
    {
        "title": "Green Cargo Pants",
        "short_description": "Durable green cargo pants with multiple pockets.",
        "price": 55.00,
        "category": "Pants"
    },
    {
        "title": "Black Skinny Jeans",
        "short_description": "Trendy black skinny jeans with stretch fabric.",
        "price": 54.99,
        "category": "Jeans"
    }
]

print("Semantic Search Engine for Clothing Products")
print("="*80)
print(f"Total products: {len(products)}\n")

# Step 2: Function to get embeddings (using GPT-4o as alternative)
def get_embedding(text):
    """
    Generate text embedding using GPT-4o (alternative method).
    Creates a simple numerical representation based on text features.
    
    Args:
        text (str): Input text to embed
        
    Returns:
        list: Embedding vector (simplified)
    """
    try:
        # Use GPT to generate a semantic summary that we can vectorize
        response = client.chat.completions.create(
            model="GPT-4o",
            messages=[
                {"role": "system", "content": "Extract key semantic features from text as comma-separated keywords."},
                {"role": "user", "content": f"Text: {text}\nKeywords:"}
            ],
            temperature=0,
            max_tokens=50
        )
        keywords = response.choices[0].message.content.strip()
        
        # Create simple embedding from text features
        # This is a simplified approach - real embeddings are more sophisticated
        words = text.lower().split()
        
        # Create feature vector based on word presence and text statistics
        embedding = [
            len(words),  # Length
            len(set(words)),  # Unique words
            sum(len(w) for w in words) / max(len(words), 1),  # Avg word length
            text.lower().count('comfortable'),
            text.lower().count('cotton'),
            text.lower().count('blue'),
            text.lower().count('black'),
            text.lower().count('warm'),
            text.lower().count('cozy'),
            text.lower().count('denim'),
            text.lower().count('leather'),
            text.lower().count('pants'),
            text.lower().count('jacket'),
            text.lower().count('jeans'),
            text.lower().count('shirt'),
        ]
        
        return embedding
    except Exception as e:
        print(f"Error getting embedding: {e}")
        return None

# Step 3: Generate embeddings for all product descriptions
print("Step 1: Generating embeddings for all products...")
for idx, product in enumerate(products, 1):
    print(f"  Processing product {idx}/{len(products)}: {product['title']}")
    product["embedding"] = get_embedding(product["short_description"])

print("✓ All product embeddings generated\n")

# Step 4: Function to compute cosine similarity
def similarity_score(vec1, vec2):
    """
    Compute cosine similarity between two vectors.
    
    Args:
        vec1 (list): First embedding vector
        vec2 (list): Second embedding vector
        
    Returns:
        float: Similarity score (0-1, higher is more similar)
    """
    # Cosine similarity = 1 - cosine distance
    return 1 - cosine(vec1, vec2)

# Step 5: Search function
def search_products(query, top_n=3):
    """
    Search for products similar to the query.
    
    Args:
        query (str): User search query
        top_n (int): Number of top results to return
        
    Returns:
        list: Top N most similar products with scores
    """
    print(f"\nSearching for: '{query}'")
    print("-"*80)
    
    # Get embedding for the query
    print("  → Generating query embedding...")
    query_embedding = get_embedding(query)
    
    if query_embedding is None:
        return []
    
    # Compute similarity scores for all products
    print("  → Computing similarity scores...")
    scores = []
    for product in products:
        if product["embedding"] is not None:
            score = similarity_score(query_embedding, product["embedding"])
            scores.append((score, product))
    
    # Sort by similarity descending
    scores.sort(key=lambda x: x[0], reverse=True)
    
    # Return top N results
    return scores[:top_n]

# Step 6: Display search results
def display_results(query, results):
    """Display search results in formatted output."""
    print(f"\n{'='*80}")
    print(f"Top {len(results)} matching products for: '{query}'")
    print(f"{'='*80}\n")
    
    for idx, (score, product) in enumerate(results, 1):
        print(f"{idx}. {product['title']}")
        print(f"   Description: {product['short_description']}")
        print(f"   Price: ${product['price']}")
        print(f"   Category: {product['category']}")
        print(f"   Similarity Score: {score:.4f}")
        print()

# Step 7: Example queries (dummy input - no manual input())
sample_queries = [
    "warm cotton sweatshirt",
    "blue denim clothing",
    "comfortable pants for exercise"
]

print("\n" + "="*80)
print("SEMANTIC SEARCH DEMO")
print("="*80)

# Process each query
all_results = []
for query in sample_queries:
    results = search_products(query, top_n=3)
    display_results(query, results)
    all_results.append((query, results))

# Step 8: Save results to file
print("\n" + "="*80)
print("Saving results to file...")
print("="*80)

with open("search_results.txt", 'w', encoding='utf-8') as f:
    f.write("SEMANTIC SEARCH RESULTS\n")
    f.write("="*80 + "\n\n")
    
    for query, results in all_results:
        f.write(f"Query: '{query}'\n")
        f.write("-"*80 + "\n\n")
        
        for idx, (score, product) in enumerate(results, 1):
            f.write(f"{idx}. {product['title']}\n")
            f.write(f"   Description: {product['short_description']}\n")
            f.write(f"   Price: ${product['price']}\n")
            f.write(f"   Category: {product['category']}\n")
            f.write(f"   Similarity Score: {score:.4f}\n\n")
        
        f.write("="*80 + "\n\n")

print("✓ Results saved to: search_results.txt")

# Summary
print("\n" + "="*80)
print("SUMMARY")
print("="*80)
print(f"Products indexed: {len(products)}")
print(f"Queries processed: {len(sample_queries)}")
print(f"Embedding model: GPT-4o (simplified feature extraction)")
print(f"Similarity metric: Cosine similarity")

print("\n" + "="*80)
print("CHALLENGES & SOLUTIONS")
print("="*80)
print("1. Embedding Generation: Need to call API for each product")
print("   Solution: Batch process all products at startup")
print("\n2. Similarity Calculation: Need efficient vector comparison")
print("   Solution: Used scipy.spatial.distance.cosine for fast computation")
print("\n3. Ranking: Need to sort by relevance")
print("   Solution: Sort by cosine similarity score in descending order")
