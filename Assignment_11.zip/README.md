# Assignment 11: AI Agent for Weather & Search Queries

## Objective
Build a Langchain-based AI agent that can:
- Answer weather-related questions using OpenWeather API
- Search for information on the web using Tavily Search API
- Automatically select the appropriate tool based on user queries

## Requirements

### Required Libraries
```bash
pip install langchain langchain-openai langchain-community langchain-tavily langgraph pyowm tiktoken
```

### API Keys Required
- **OpenAI API**: For LLM (GPT-4o model)
- **OpenWeather API**: For weather information
- **Tavily API**: For web search capabilities

## Code Structure

### 1. Tool Definitions
- **get_weather**: Retrieves current weather information for a given city
- **tavily_search_tool**: Searches the web for real-time information

### 2. Agent Setup
- Uses `create_react_agent` from Langgraph
- Agent automatically selects appropriate tool based on query
- Maintains conversation history

### 3. Conversation Loop
- Uses mock questions list for automatic testing
- No manual `input()` required
- Displays agent's tool calling process
- Saves results to `output.txt` file

## How to Run

1. **Configure API keys in `.env` file**:
```env
OPENAI_BASE_URL=your-openai-base-url-here
OPENAI_API_KEY=your-openai-api-key-here
OPENWEATHERMAP_API_KEY=your-openweather-api-key-here
TAVILY_API_KEY=your-tavily-api-key-here
```

2. **Run the program**:
```bash
python weather_search_agent.py
```

## Example Queries

The agent can handle questions like:
- "What's the weather in Hanoi?" → Calls get_weather tool
- "Tell me about the latest news in AI" → Calls tavily_search_tool
- "Who won the last World Cup?" → Uses LLM knowledge
- "What's the temperature in Paris?" → Calls get_weather tool

## Expected Results

✅ Agent automatically identifies query type
✅ Calls the correct tool (weather or search)
✅ Returns well-formatted, user-friendly responses
✅ Maintains conversation context
✅ Saves all results to output.txt

## Concepts Covered

1. **Langchain Tools**: Define custom tools with `@tool` decorator
2. **API Integration**: Integrate OpenWeather and Tavily APIs
3. **Agent Routing**: Agent automatically selects appropriate tool
4. **Conversation History**: Maintain conversation context
5. **ReAct Pattern**: Reasoning + Acting approach

## Challenges and Solutions

### Challenge 1: Tool Selection
**Problem**: Agent needs to know when to use weather tool vs search tool

**Solution**: 
- Write clear descriptions for each tool in docstrings
- LLM uses descriptions to decide which tool to use

### Challenge 2: API Rate Limits
**Problem**: APIs have request limits

**Solution**:
- Use mock questions instead of infinite input() loop
- Limit Tavily results (max_results=3)

### Challenge 3: Response Formatting
**Problem**: Raw API results may be hard to read

**Solution**:
- LLM automatically formats results into natural language
- Agent combines information from multiple sources when needed

### Challenge 4: City Name Recognition
**Problem**: OpenWeather API may not recognize all city names

**Solution**:
- Use specific city names (e.g., "Tuy Hoa, Phu Yen" instead of just "Phu Yen")
- Provide alternative city names when needed

## Optional Enhancements

1. **Chat History UI**: Display conversation history in a better format
2. **Error Handling**: Handle cases when APIs are unavailable
3. **Multi-language Support**: Support queries in Vietnamese
4. **Caching**: Cache results to reduce API calls
5. **Streaming Response**: Display responses in real-time

## Output

The program generates an `output.txt` file containing:
- All user queries
- Agent responses
- Weather information for Da Nang, Hanoi, and Tuy Hoa (Phu Yen)
- Latest AI news from web search
- World Cup winner information

## References

- [Langchain Documentation](https://python.langchain.com/docs/get_started/introduction)
- [OpenWeather API](https://openweathermap.org/api)
- [Tavily Search API](https://app.tavily.com/)
- [Langgraph ReAct Agent](https://langchain-ai.github.io/langgraph/tutorials/introduction/)
