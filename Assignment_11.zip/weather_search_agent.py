"""
Assignment 11: AI Agent for Weather & Search Queries
Build a Langchain-based AI agent with OpenWeather and Tavily Search tools
"""

import os
from langchain.tools import tool
from langchain_openai import ChatOpenAI
from langchain_community.utilities import OpenWeatherMapAPIWrapper
from langchain_community.tools.tavily_search import TavilySearchResults
from langgraph.prebuilt import create_react_agent

# Load environment variables
try:
    from dotenv import load_dotenv
    load_dotenv()
except ImportError:
    pass

# Step 1: Setup API keys (use placeholders - replace with your actual keys)
os.environ["OPENAI_BASE_URL"] = os.getenv("OPENAI_BASE_URL", "your-openai-base-url-here")
os.environ["OPENAI_API_KEY"] = os.getenv("OPENAI_API_KEY", "your-openai-api-key-here")
os.environ["OPENWEATHERMAP_API_KEY"] = os.getenv("OPENWEATHERMAP_API_KEY", "your-openweather-api-key-here")
os.environ["TAVILY_API_KEY"] = os.getenv("TAVILY_API_KEY", "your-tavily-api-key-here")

# Step 2: Define weather tool using Langchain wrapper
weather = OpenWeatherMapAPIWrapper()

@tool
def get_weather(city: str) -> str:
    """Get the current weather for a given city.
    Args: city (str): The name of the city to get the weather for.
    Returns: str: A string describing the current weather in the specified city.
    """
    print(f"🌤️  get_weather tool calling: Getting weather for {city}")
    return weather.run(city)

# Step 3: Initialize Tavily search tool
tavily_search_tool = TavilySearchResults(
    max_results=3,
    topic="general",
)

# Step 4: Initialize OpenAI LLM
llm = ChatOpenAI(
    model="GPT-4o",
    base_url=os.getenv("OPENAI_BASE_URL"),
    api_key=os.getenv("OPENAI_API_KEY"),
    temperature=0.7,
)

# Step 5: Setup Langchain agent with both tools
tools = [get_weather, tavily_search_tool]

agent = create_react_agent(
    model=llm,
    tools=tools,
)

print("=" * 60)
print("🤖 Welcome to the AI Assistant!")
print("=" * 60)
print("I can help you with:")
print("  • Weather information for any city")
print("  • Real-time web search on any topic")
print("Type 'exit' to stop.")
print("=" * 60)

# Mock user questions for automatic input
mock_questions = [
    "What's the weather in Da Nang?",
    "What's the weather in Hanoi?",
    "What's the weather in Tuy Hoa, Phu Yen?",
    "Tell me about the latest news in AI.",
    "Who won the last World Cup?",
    "exit",
]

messages = []
output_lines = []

# Add header to output
output_lines.append("=" * 80)
output_lines.append("AI AGENT - WEATHER & SEARCH QUERIES OUTPUT")
output_lines.append("Assignment 11")
output_lines.append("=" * 80)
output_lines.append("")

for user_input in mock_questions:
    print(f"\n👤 User: {user_input}")
    output_lines.append(f"\n{'='*80}")
    output_lines.append(f"User: {user_input}")
    output_lines.append(f"{'='*80}")
    
    if user_input.lower() == "exit":
        print("👋 Goodbye!")
        output_lines.append("\n👋 Goodbye!")
        break
    
    # Invoke agent with conversation history
    response = agent.invoke({"messages": messages + [{"role": "user", "content": user_input}]})
    
    # Extract assistant's response
    assistant_message = response["messages"][-1].content
    
    # Update conversation history
    messages.append({"role": "user", "content": user_input})
    messages.append({"role": "assistant", "content": assistant_message})
    
    print(f"\n🤖 AI: {assistant_message}")
    print("-" * 60)
    
    output_lines.append(f"\nAI Response:")
    output_lines.append(assistant_message)
    output_lines.append("\n" + "-" * 80)

# Save to output file
output_file = "output.txt"
with open(output_file, 'w', encoding='utf-8') as f:
    f.write('\n'.join(output_lines))

print(f"\n✓ Results saved to: {output_file}")
