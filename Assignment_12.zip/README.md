# Assignment 12: Satellite Image Cloud Detection via Azure OpenAI Inference

## Objective

Build a lightweight, user-friendly interface where users can upload a satellite image and instantly receive a label — "Cloudy" or "Clear" — by leveraging a Large Language Model (LLM) deployed on Azure OpenAI. The LLM is prompted to perform visual scene analysis and classification, removing the need for users to set up or maintain conventional deep learning models.

## Problem Statement

Manual inspection of satellite imagery to identify cloud-covered scenes is time-consuming and does not scale for large datasets. Traditional solutions require deploying or fine-tuning pretrained image classification models, which can be technically challenging for many users. 

By leveraging the image understanding capabilities of modern LLMs via Azure OpenAI, we can bypass complex model management and provide an accessible, code-free cloud detection solution suitable for integration into various industries such as media, agriculture, logistics, and climate analytics.

## Task

Build a minimal application that:
- Accepts satellite images as input (e.g., .jpg, .png)
- Uses LLM for inference with multimodal data (image)
- Returns an output label: "Cloudy" or "Clear"
- Optionally displays confidence score
- Uses dummy input list (auto input) - no manual input()

## Inputs / Shared Artifacts

### Azure OpenAI Resource
- API key
- Endpoint URL
- Deployment name (GPT-4o with vision capabilities)

### Sample Images
- Dataset: [Kaggle Cloud Cover Detection](https://www.kaggle.com/datasets/hmendonca/cloud-cover-detection/data)
- Or use direct image URLs for testing

## Expected Outcome

For each uploaded satellite image, the system should:
- Return a single label: either "Cloudy" or "Clear"
- Optionally display the confidence score (e.g., 92.4% confidence in prediction)
- Visually present the image back to the user with the predicted label shown

Example:
- **Input**: https://...jpg
- **Output**: 
  - Prediction: Cloudy
  - Confidence: 95%

## Concepts Covered

1. **Azure OpenAI API usage**: Using GPT-4o with vision capabilities
2. **Image Classification**: Binary classification (Cloudy vs Clear)
3. **Multimodal AI**: Passing image data to LLM
4. **Structured Output**: Using Pydantic models for response parsing
5. **Base64 Encoding**: Converting images for API transmission

## Implementation Steps

1. **Setup Azure OpenAI Client**: Configure endpoint, API key, and deployment
2. **Load Images**: From URLs or local files, convert to base64
3. **Construct Prompt**: Create system and user messages with image data
4. **Define Output Schema**: Use Pydantic BaseModel for structured response
5. **Call API**: Invoke LLM with structured output
6. **Parse Results**: Extract prediction and confidence score
7. **Save Output**: Write results to output.txt file

## Challenges and Solutions

### Challenge 1: Image Format
**Problem**: API requires base64-encoded images

**Solution**: 
- Use `base64.b64encode()` to convert image bytes
- Support both URL and local file inputs

### Challenge 2: Structured Output
**Problem**: Need consistent JSON response format

**Solution**:
- Use Pydantic BaseModel to define schema
- Use `with_structured_output()` method

### Challenge 3: Prompt Engineering
**Problem**: LLM needs clear instructions for classification

**Solution**:
- Provide specific system prompt
- Request single-word response (Clear/Cloudy)
- Ask for confidence score

## Sample Images for Testing

Using cloud cover detection dataset images:
1. Clear sky image
2. Partially cloudy image
3. Fully cloudy image

## Output Format

The program generates an `output.txt` file containing:
- Image URL/path
- Prediction (Cloudy/Clear)
- Confidence score
- Timestamp

## References

- [Azure OpenAI Vision Documentation](https://learn.microsoft.com/en-us/azure/ai-services/openai/how-to/gpt-with-vision)
- [Langchain Structured Output](https://python.langchain.com/docs/how_to/structured_output/)
- [Kaggle Cloud Cover Dataset](https://www.kaggle.com/datasets/hmendonca/cloud-cover-detection/data)
