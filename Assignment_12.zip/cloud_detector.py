"""
Assignment 12: Satellite Image Cloud Detection via Azure OpenAI Inference
Classify satellite images as 'Clear' or 'Cloudy' using GPT-4o vision capabilities
"""

import os
import base64
import requests
from io import BytesIO
from PIL import Image
from langchain_openai import AzureChatOpenAI
from pydantic import BaseModel, Field

# Load environment variables
try:
    from dotenv import load_dotenv
    load_dotenv()
except ImportError:
    pass

# Step 1: Setup Azure OpenAI Configuration
os.environ["AZURE_OPENAI_ENDPOINT"] = os.getenv("AZURE_OPENAI_ENDPOINT", "your-endpoint-here")
os.environ["AZURE_OPENAI_API_KEY"] = os.getenv("AZURE_OPENAI_API_KEY", "your-api-key-here")
os.environ["AZURE_DEPLOYMENT_NAME"] = os.getenv("AZURE_DEPLOYMENT_NAME", "GPT-4o")

# Step 2: Define Output Schema using Pydantic
class CloudDetectionResponse(BaseModel):
    """Schema for cloud detection response"""
    result: str = Field(description="The result of the classification: either 'Clear' or 'Cloudy'")
    accuracy: float = Field(description="The accuracy/confidence of the result as a percentage (0-100)")

# Step 3: Initialize Azure OpenAI LLM
llm = AzureChatOpenAI(
    azure_endpoint=os.getenv("AZURE_OPENAI_ENDPOINT"),
    azure_deployment=os.getenv("AZURE_DEPLOYMENT_NAME"),
    api_key=os.getenv("AZURE_OPENAI_API_KEY"),
    api_version="2024-02-15-preview",
)

# Create LLM with structured output
llm_with_structured_output = llm.with_structured_output(CloudDetectionResponse)

def load_image_from_url(image_url):
    """
    Load image from URL and convert to base64
    
    Args:
        image_url (str): URL of the image
        
    Returns:
        str: Base64 encoded image data
    """
    print(f"📥 Loading image from: {image_url}")
    response = requests.get(image_url)
    image_bytes = response.content
    image_data_base64 = base64.b64encode(image_bytes).decode("utf-8")
    return image_data_base64

def classify_satellite_image(image_url):
    """
    Classify satellite image as Clear or Cloudy
    
    Args:
        image_url (str): URL of the satellite image
        
    Returns:
        CloudDetectionResponse: Classification result with confidence
    """
    # Load and encode image
    image_data_base64 = load_image_from_url(image_url)
    
    # Construct message with image
    message = [
        {
            "role": "system",
            "content": """Based on the satellite image provided, classify the scene as either:
'Clear' (no clouds) or 'Cloudy' (with clouds).
Respond with only one word: either 'Clear' or 'Cloudy' and Accuracy. Do not provide explanations."""
        },
        {
            "role": "user",
            "content": [
                {
                    "type": "text",
                    "text": "Classify the scene as either: 'Clear' or 'Cloudy' and Accuracy."
                },
                {
                    "type": "image_url",
                    "image_url": {"url": f"data:image/jpeg;base64,{image_data_base64}"}
                }
            ]
        }
    ]
    
    # Call Azure OpenAI
    print("🤖 Analyzing image...")
    try:
        result = llm_with_structured_output.invoke(message)
        print(f"✓ Prediction: {result.result}")
        print(f"✓ Confidence: {result.accuracy}%")
        return result
    except Exception as e:
        print(f"✗ Error: {e}")
        return None

# Step 4: Mock input - 3 sample satellite images
print("=" * 80)
print("SATELLITE IMAGE CLOUD DETECTION")
print("Assignment 12")
print("=" * 80)
print()

# Sample images from cloud cover detection dataset
sample_images = [
    {
        "url": "https://images.pexels.com/photos/53594/blue-clouds-day-fluffy-53594.jpeg",
        "description": "Blue sky with fluffy clouds"
    },
    {
        "url": "https://images.pexels.com/photos/209831/pexels-photo-209831.jpeg",
        "description": "Clear blue sky"
    },
    {
        "url": "https://images.pexels.com/photos/158163/clouds-cloudporn-weather-lookup-158163.jpeg",
        "description": "Heavy cloud coverage"
    }
]

# Process each image
results = []
output_lines = []

output_lines.append("=" * 80)
output_lines.append("SATELLITE IMAGE CLOUD DETECTION RESULTS")
output_lines.append("Assignment 12 ")
output_lines.append("=" * 80)
output_lines.append("")

for idx, image_info in enumerate(sample_images, 1):
    print(f"\n{'='*80}")
    print(f"Image {idx}/{len(sample_images)}: {image_info['description']}")
    print(f"{'='*80}")
    print(f"URL: {image_info['url']}")
    
    output_lines.append(f"\n{'='*80}")
    output_lines.append(f"Image {idx}: {image_info['description']}")
    output_lines.append(f"{'='*80}")
    output_lines.append(f"URL: {image_info['url']}")
    
    # Classify image
    result = classify_satellite_image(image_info['url'])
    
    if result:
        results.append({
            "image": image_info['description'],
            "url": image_info['url'],
            "prediction": result.result,
            "confidence": result.accuracy
        })
        
        output_lines.append(f"\nPrediction: {result.result}")
        output_lines.append(f"Confidence: {result.accuracy}%")
    else:
        output_lines.append("\nPrediction: Error")
        output_lines.append("Confidence: N/A")
    
    output_lines.append("")
    print("-" * 80)

# Save results to file
output_file = "output.txt"
with open(output_file, 'w', encoding='utf-8') as f:
    f.write('\n'.join(output_lines))

print(f"\n✓ Results saved to: {output_file}")

# Summary
print("\n" + "=" * 80)
print("SUMMARY")
print("=" * 80)
print(f"Total images processed: {len(sample_images)}")
print(f"Successful classifications: {len(results)}")
print("\nClassification Results:")
for r in results:
    print(f"  • {r['image']}: {r['prediction']} ({r['confidence']}% confidence)")
print("\n✓ Cloud detection complete!")
