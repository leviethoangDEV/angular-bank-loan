# Assignment 13: Patient Information Collection and Advisory Chatbot Agent

## Objectives

Build an AI-powered medical chatbot that:
- Collects patient information (symptoms) interactively
- Provides preliminary health advice based on collected data
- Uses **LangGraph** for conversation flow management
- Employs **AzureChatOpenAI** as the language model
- Optionally integrates **Tavily** for real-time web information

## Problem Statement

Patients need quick preliminary health assessments before seeing healthcare professionals. This chatbot:
- Engages users naturally to gather patient details
- Analyzes information to offer relevant health advice
- Enhances advice with real-time information (optional)
- Uses LangGraph for guided dialogue flow control

## Requirements

- Python 3.x environment
- Packages: `langchain`, `langgraph`, `langchain-openai`, `faiss-cpu`, `tavily-python`
- Azure OpenAI API access (GPT-4o model)
- (Optional) Tavily API key for web search

## Implementation

### Architecture Components

1. **LLM**: AzureChatOpenAI (GPT-4o)
2. **Knowledge Base**: Mock medical advice documents
3. **Retriever**: Simple keyword-based matching (see note below)
4. **Tools**:
   - `retrieve_advice`: Searches internal medical knowledge base
   - `tavily_tool`: Searches web for real-time information
5. **Graph Structure**:
   - `call_model` node: Invokes LLM with tools
   - `tools` node: Executes tool calls
   - Conditional routing: Decides tool usage or end conversation

### Conversation Flow

**Part 1 - English Consultation:**
1. User provides symptoms in English (e.g., "I feel tired and have a sore throat")
2. Agent responds in English with medical advice

**Part 2 - Vietnamese FPT Care Consultation:**
1. User asks in Vietnamese (e.g., "Tôi bị đau đầu và sốt nhẹ")
2. Agent responds as FPT Care doctor in Vietnamese
3. All conversations saved to `output.txt`

## Mock Medical Knowledge Base

**English documents:**
- Sore throat treatment (warm fluids, avoid cold beverages)
- Fever management (rest and hydration)
- Dizziness assessment (check blood pressure)
- Persistent cough evaluation
- Fatigue causes (iron deficiency, poor sleep)

**Vietnamese documents (FPT Care):**
- Đau đầu: nghỉ ngơi trong phòng tối, tránh ánh sáng mạnh
- Sốt nhẹ: nghỉ ngơi, uống nhiều nước, chườm mát
- Đau họng: súc miệng nước muối ấm, uống nước ấm

## Implementation Details

**Vector Embeddings**: This implementation uses **Azure OpenAI Embeddings** (text-embedding-3-small) with **FAISS vector store** for semantic document retrieval. The system:
- Embeds medical knowledge documents using Azure OpenAI
- Stores vectors in FAISS for fast similarity search
- Retrieves relevant documents based on semantic similarity to user queries

**Note**: Requires API key with access to both GPT-4o and text-embedding-3-small models.

## Concepts Covered

1. **LangGraph**: State management and conversation flow control
2. **Tool Integration**: Custom tools with `@tool` decorator
3. **Conditional Routing**: Dynamic decision-making in conversation
4. **RAG Pattern**: Retrieve-Augment-Generate (simplified version)
5. **State Management**: MessagesState for conversation history

## Expected Output

**English Consultation:**
- Rest and hydration recommendations
- Throat soothing techniques (gargle, lozenges)
- Symptom monitoring guidance
- When to see a doctor

**Vietnamese FPT Care Consultation:**
- Tư vấn bằng tiếng Việt từ bác sĩ FPT Care
- Nguyên nhân phổ biến và cách xử lý
- Khi nào cần đến gặp bác sĩ ngay
- Lời khuyên từ FPT Care

## Safety Disclaimer

**IMPORTANT**: Educational demonstration only. NOT a replacement for professional medical advice. Always consult qualified healthcare professionals for medical concerns.

## References

- [LangGraph Documentation](https://langchain-ai.github.io/langgraph/)
- [LangChain Tools](https://python.langchain.com/docs/how_to/custom_tools/)
- [Azure OpenAI Service](https://learn.microsoft.com/en-us/azure/ai-services/openai/)
