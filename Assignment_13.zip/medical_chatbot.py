"""
Assignment 13: Patient Information Collection and Advisory Chatbot Agent
Build a medical chatbot using LangGraph with RAG and tools
"""

import os
from langchain_core.documents import Document
from langgraph.graph import StateGraph, MessagesState, START, END
from langchain_community.tools.tavily_search import TavilySearchResults
from langchain_openai import AzureChatOpenAI, AzureOpenAIEmbeddings
from langchain_community.vectorstores import FAISS
from langgraph.prebuilt import ToolNode
from langchain_core.messages import SystemMessage, HumanMessage
from langchain.tools import tool

# Load environment variables
try:
    from dotenv import load_dotenv
    load_dotenv()
except ImportError:
    pass

print("=" * 80)
print("MEDICAL CHATBOT AGENT")
print("Assignment 13")
print("=" * 80)
print()

# Step 1: Setup API Keys
os.environ["AZURE_OPENAI_LLM_ENDPOINT"] = os.getenv("AZURE_OPENAI_LLM_ENDPOINT", "your-endpoint-here")
os.environ["AZURE_OPENAI_LLM_API_KEY"] = os.getenv("AZURE_OPENAI_LLM_API_KEY", "your-api-key-here")
os.environ["AZURE_OPENAI_LLM_MODEL"] = os.getenv("AZURE_OPENAI_LLM_MODEL", "GPT-4o")

os.environ["AZURE_OPENAI_EMBEDDING_ENDPOINT"] = os.getenv("AZURE_OPENAI_EMBEDDING_ENDPOINT", "your-endpoint-here")
os.environ["AZURE_OPENAI_EMBEDDING_API_KEY"] = os.getenv("AZURE_OPENAI_EMBEDDING_API_KEY", "your-api-key-here")
os.environ["AZURE_OPENAI_EMBED_MODEL"] = os.getenv("AZURE_OPENAI_EMBED_MODEL", "text-embedding-3-small")

os.environ["TAVILY_API_KEY"] = os.getenv("TAVILY_API_KEY", "")

# Step 2: Setup LLM
print("🔧 Initializing Azure OpenAI LLM...")
llm = AzureChatOpenAI(
    azure_endpoint=os.getenv("AZURE_OPENAI_LLM_ENDPOINT"),
    api_key=os.getenv("AZURE_OPENAI_LLM_API_KEY"),
    azure_deployment=os.getenv("AZURE_OPENAI_LLM_MODEL"),
    api_version="2024-02-15-preview",
)

# Step 3: Setup FAISS Retriever from Mock Medical Knowledge Base
print("📚 Setting up medical knowledge base...")

# Mock medical advice documents (English + Vietnamese)
mock_chunks = [
    Document(
        page_content="Patients with a sore throat should drink warm fluids and avoid cold beverages."
    ),
    Document(
        page_content="Mild fevers under 38.5°C can often be managed with rest and hydration."
    ),
    Document(
        page_content="If a patient reports dizziness, advise checking their blood pressure and hydration level."
    ),
    Document(
        page_content="Persistent coughs lasting more than 2 weeks should be evaluated for infections or allergies."
    ),
    Document(
        page_content="Patients experiencing fatigue should consider iron deficiency or poor sleep as potential causes."
    ),
    # Vietnamese documents for FPT Care
    Document(
        page_content="Bệnh nhân bị đau đầu nên nghỉ ngơi trong phòng tối, tránh ánh sáng mạnh và tiếng ồn."
    ),
    Document(
        page_content="Sốt nhẹ dưới 38.5°C có thể được xử lý bằng cách nghỉ ngơi, uống nhiều nước và chườm mát."
    ),
    Document(
        page_content="Nếu bệnh nhân bị đau họng, nên súc miệng nước muối ấm và uống nhiều nước ấm."
    ),
]

# Create embeddings with proper Azure OpenAI Embeddings
print("🔍 Creating vector embeddings with Azure OpenAI...")
embedding_model = AzureOpenAIEmbeddings(
    model=os.getenv("AZURE_OPENAI_EMBED_MODEL"),
    api_key=os.getenv("AZURE_OPENAI_EMBEDDING_API_KEY"),
    azure_endpoint=os.getenv("AZURE_OPENAI_EMBEDDING_ENDPOINT"),
    api_version="2024-02-15-preview",
)

# Create FAISS vector store
db = FAISS.from_documents(mock_chunks, embedding_model)
retriever = db.as_retriever()

# Step 4: Define Tools

# Tool 1: Retrieve Advice from Knowledge Base
@tool
def retrieve_advice(user_input: str) -> str:
    """Searches internal documents for relevant patient advice."""
    print(f"🔍 Retrieving advice for: {user_input}")
    docs = retriever.get_relevant_documents(user_input)
    return "\n".join(doc.page_content for doc in docs)

# Tool 2: Tavily Search (Optional)
tavily_tool = TavilySearchResults()

# Bind tools to LLM
llm_with_tools = llm.bind_tools([retrieve_advice, tavily_tool])

# Step 5: Define Graph Nodes

def call_model(state: MessagesState):
    """Model node - invokes LLM with tools"""
    messages = state["messages"]
    response = llm_with_tools.invoke(messages)
    return {"messages": [response]}

def should_continue(state: MessagesState):
    """Conditional routing - check if tools should be called"""
    last_message = state["messages"][-1]
    if last_message.tool_calls:
        return "tools"
    return END

# Step 6: Build the Graph
print("🏗️  Building conversation graph...")

tool_node = ToolNode([retrieve_advice, tavily_tool])

graph_builder = StateGraph(MessagesState)
graph_builder.add_node("call_model", call_model)
graph_builder.add_node("tools", tool_node)

graph_builder.add_edge(START, "call_model")
graph_builder.add_conditional_edges("call_model", should_continue, ["tools", END])
graph_builder.add_edge("tools", "call_model")

graph = graph_builder.compile()

print("✓ Graph compiled successfully!")
print()

# Step 7: Run Conversation with Mock Input
print("=" * 80)
print("STARTING MEDICAL CONSULTATION")
print("=" * 80)
print()

# Mock conversation - 2 parts: English and Vietnamese
mock_questions = [
    {
        "lang": "English",
        "question": "I feel tired and have a sore throat. What should I do?"
    },
    {
        "lang": "Vietnamese",
        "question": "Tôi bị đau đầu và sốt nhẹ. Bác sĩ FPT Care có thể tư vấn giúp tôi không?"
    }
]

output_lines = []
output_lines.append("=" * 80)
output_lines.append("MEDICAL CHATBOT CONVERSATION LOG")
output_lines.append("Assignment 13")
output_lines.append("=" * 80)
output_lines.append("")
output_lines.append("DISCLAIMER: This is preliminary advice only. Always consult healthcare professionals.")
output_lines.append("")

for idx, item in enumerate(mock_questions, 1):
    lang = item["lang"]
    user_input = item["question"]
    
    print(f"\n{'='*80}")
    print(f"CONSULTATION {idx}/{len(mock_questions)} - Language: {lang}")
    print(f"{'='*80}")
    
    output_lines.append(f"\n{'='*80}")
    output_lines.append(f"CONSULTATION {idx} - Language: {lang}")
    output_lines.append(f"{'='*80}")
    
    # System message based on language
    if lang == "Vietnamese":
        system_msg = SystemMessage(
            content="Bạn là bác sĩ tư vấn của FPT Care. Sử dụng tools nếu cần. "
            "Cung cấp lời khuyên sức khỏe sơ bộ dựa trên triệu chứng. "
            "Luôn nhắc nhở người dùng đến gặp bác sĩ chuyên khoa nếu triệu chứng nghiêm trọng. "
            "Trả lời bằng tiếng Việt."
        )
    else:
        system_msg = SystemMessage(
            content="You are a helpful medical assistant. Use tools if needed. "
            "Provide preliminary health advice based on symptoms. "
            "Always remind users to consult healthcare professionals for serious concerns."
        )
    
    print(f"👤 Patient: {user_input}")
    output_lines.append(f"\nPatient: {user_input}")
    output_lines.append("")
    
    # Invoke graph
    result = graph.invoke(
        {
            "messages": [
                system_msg,
                HumanMessage(content=user_input)
            ]
        }
    )
    
    # Extract final response
    final_response = result["messages"][-1].content
    
    print(f"\n🤖 Medical Assistant: {final_response}")
    print("-" * 80)
    
    output_lines.append(f"Medical Assistant: {final_response}")
    output_lines.append("")
    output_lines.append("-" * 80)
    output_lines.append("")

# Save output
output_file = "output.txt"
with open(output_file, 'w', encoding='utf-8') as f:
    f.write('\n'.join(output_lines))

print(f"\n✓ Conversation saved to: {output_file}")

# Summary
print("\n" + "=" * 80)
print("SUMMARY")
print("=" * 80)
print(f"Total consultations processed: {len(mock_questions)}")
print("Languages: English, Vietnamese (FPT Care)")
print("Tools available: retrieve_advice, tavily_search")
print("Graph nodes: call_model, tools")
print("\n✓ Medical chatbot consultation complete!")
print("\n⚠️  REMINDER: This is for educational purposes only.")
print("   Always consult qualified healthcare professionals for medical advice.")
