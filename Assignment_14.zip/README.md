# Assignment 14: RAG Chatbot for Product and Policy Support in Retail

## Objective

Develop a Retrieval-Augmented Generation (RAG) chatbot that helps retail employees and customers quickly get accurate answers about:
- Product details
- Store policies
- Return/exchange guidelines for a large retailer (Walmart)

The chatbot references in-memory retail documents and generates clear, human-friendly answers using Azure OpenAI.

## Problem Statement

Retail staff and customers often have questions about:
- Product specifications and warranties
- In-store services
- Return/exchange policies

Without instant access to information:
- Staff spend time searching manuals or waiting for approvals
- Customers face longer wait times

By deploying a RAG chatbot, retail operations can deliver fast, reliable, and context-aware answers that improve service efficiency and customer satisfaction.

## Requirements

- Azure OpenAI Resource: API key, endpoint URL, and deployment name
- Mock dataset of Walmart policy and product documents (15 entries)
- Python packages: `langchain`, `langchain-openai`, `langchain-community`, `langgraph`, `faiss-cpu`

## Implementation

### Architecture

1. **Documents**: 15 Walmart policy documents (returns, warranties, shipping, etc.)
2. **Embeddings**: Azure OpenAI Embeddings (text-embedding-3-small)
3. **Vector Store**: FAISS for fast similarity search
4. **LLM**: Azure OpenAI (GPT-4o)
5. **Graph**: LangGraph with retrieve → generate nodes
6. **State**: RAGState with question, context, answer

### RAG Flow

1. **Retrieve Node**: Get relevant documents from vector store
2. **Generate Node**: LLM generates answer using retrieved context
3. User question → Retrieve → Generate → Answer

## Walmart Policy Documents (15 entries)

1. Electronics return: 30 days with receipt and original packaging
2. Grocery items: 90 days return with proof of purchase
3. Electronics warranty: 1-year on most items
4. Walmart Plus: Free shipping, no minimum order
5. Prescription medications: Not eligible for return
6. Open-box items: Eligible for return with accessories
7. No receipt: Store credit with valid photo ID
8. Price matching: Walmart.com and local competitor ads
9. Vision Center: 60 days return/exchange with receipt
10. Cell phones: Must be unlocked, personal data erased
11. Gift cards: Cannot be redeemed for cash
12. Seasonal merchandise: Modified return windows
13. Bicycles: 90 days return if not used outdoors
14. Online orders: Return in-store or by mail
15. Fraud prevention: Right to deny suspicious returns

## Expected Output

**Example Q&A:**
- **Question**: "Can I return an opened Amazon Kindle?"
- **Retrieved Context**: Kindle return policy, open-box policy
- **Generated Answer**: "You may return an opened Amazon Kindle within 30 days if it is in new condition and includes all accessories. See Amazon policy for details."

## Concepts Covered

1. **RAG Pattern**: Retrieval-Augmented Generation
2. **Vector Embeddings**: Semantic search with Azure OpenAI
3. **FAISS Vector Store**: Fast similarity search
4. **LangGraph**: State management for RAG workflow
5. **Prompt Engineering**: Context-aware answer generation

## Key Features

- 15 Walmart policy documents embedded in vector store
- Semantic search retrieves top-k relevant documents
- LLM generates contextually correct answers
- Cites retrieved information in responses
- Saves Q&A to output.txt

## Reflection

**How RAG improves retail support vs traditional FAQs:**
- **Dynamic**: Handles natural language questions, not just keywords
- **Contextual**: Combines multiple policy documents for comprehensive answers
- **Scalable**: Easy to add new policies without rewriting FAQs
- **Accurate**: Cites source documents, reducing misinformation
- **Efficient**: Instant answers vs manual search through manuals

## References

- [LangGraph Documentation](https://langchain-ai.github.io/langgraph/)
- [LangChain RAG Tutorial](https://python.langchain.com/docs/tutorials/rag/)
- [Azure OpenAI Service](https://learn.microsoft.com/en-us/azure/ai-services/openai/)
- [FAISS Vector Store](https://python.langchain.com/docs/integrations/vectorstores/faiss)
