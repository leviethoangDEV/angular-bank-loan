"""
Assignment 14: RAG Chatbot for Product and Policy Support in Retail
Build a RAG chatbot for Walmart using LangGraph, FAISS, and Azure OpenAI
"""

import os
from typing import TypedDict, Optional
from langchain_openai import AzureChatOpenAI, AzureOpenAIEmbeddings
from langchain_community.docstore.in_memory import InMemoryDocstore
from langchain_community.vectorstores import FAISS
from langchain_core.documents import Document
from langchain_core.prompts import ChatPromptTemplate
from langgraph.graph import StateGraph, END

# Load environment variables
try:
    from dotenv import load_dotenv
    load_dotenv()
except ImportError:
    pass

print("=" * 80)
print("WALMART RAG CHATBOT")
print("Assignment 14")
print("=" * 80)
print()

# Step 1: Setup Environment Variables
os.environ["AZURE_OPENAI_EMBEDDING_ENDPOINT"] = os.getenv("AZURE_OPENAI_EMBEDDING_ENDPOINT", "your-endpoint-here")
os.environ["AZURE_OPENAI_EMBEDDING_API_KEY"] = os.getenv("AZURE_OPENAI_EMBEDDING_API_KEY", "your-key-here")
os.environ["AZURE_OPENAI_EMBED_MODEL"] = os.getenv("AZURE_OPENAI_EMBED_MODEL", "text-embedding-3-small")

os.environ["AZURE_OPENAI_LLM_ENDPOINT"] = os.getenv("AZURE_OPENAI_LLM_ENDPOINT", "your-endpoint-here")
os.environ["AZURE_OPENAI_LLM_API_KEY"] = os.getenv("AZURE_OPENAI_LLM_API_KEY", "your-key-here")
os.environ["AZURE_OPENAI_LLM_MODEL"] = os.getenv("AZURE_OPENAI_LLM_MODEL", "GPT-4o")

# Step 2: Sample Walmart Documents (15 entries)
print("📚 Loading Walmart policy documents...")
docs = [
    Document(page_content="Walmart customers may return electronics within 30 days with a receipt and original packaging."),
    Document(page_content="Grocery items at Walmart can be returned within 90 days with proof of purchase, except perishable products."),
    Document(page_content="Walmart offers a 1-year warranty on most electronics and appliances. See product details for exceptions."),
    Document(page_content="Walmart Plus members get free shipping with no minimum order amount."),
    Document(page_content="Prescription medications purchased at Walmart are not eligible for return or exchange."),
    Document(page_content="Open-box items are eligible for return at Walmart within the standard return period, but must include all original accessories."),
    Document(page_content="If a Walmart customer does not have a receipt, most returns are eligible for store credit with valid photo identification."),
    Document(page_content="Walmart allows price matching for identical items found on Walmart.com and local competitor ads."),
    Document(page_content="Walmart Vision Center purchases may be returned or exchanged within 60 days with a receipt."),
    Document(page_content="Returns on cell phones at Walmart require the device to be unlocked and all personal data erased."),
    Document(page_content="Walmart gift cards cannot be redeemed for cash except where required by law."),
    Document(page_content="Seasonal merchandise at Walmart (e.g., holiday decorations) may have modified return windows, see in-store signage."),
    Document(page_content="Bicycles purchased at Walmart can be returned within 90 days if not used outdoors and with all accessories present."),
    Document(page_content="For online Walmart orders, customers can return items in store or by mail using the prepaid label."),
    Document(page_content="Walmart reserves the right to deny returns suspected of fraud or abuse."),
]

print(f"✓ Loaded {len(docs)} policy documents")

# Step 3: Typed State for LangGraph
class RAGState(TypedDict):
    question: str
    context: Optional[str]
    answer: Optional[str]

# Step 4: Embedding & Vector Store
print("🔍 Creating vector embeddings...")
embeddings = AzureOpenAIEmbeddings(
    model=os.getenv("AZURE_OPENAI_EMBED_MODEL"),
    api_key=os.getenv("AZURE_OPENAI_EMBEDDING_API_KEY"),
    azure_endpoint=os.getenv("AZURE_OPENAI_EMBEDDING_ENDPOINT"),
    api_version="2024-02-15-preview",
)

vectorstore = FAISS.from_documents(
    docs,
    embeddings,
    docstore=InMemoryDocstore({str(i): doc for i, doc in enumerate(docs)}),
)

retriever = vectorstore.as_retriever(search_kwargs={"k": 2})
print("✓ Vector store created")

# Step 5: Azure Chat Model
print("🤖 Initializing Azure OpenAI LLM...")
llm = AzureChatOpenAI(
    azure_endpoint=os.getenv("AZURE_OPENAI_LLM_ENDPOINT"),
    api_key=os.getenv("AZURE_OPENAI_LLM_API_KEY"),
    azure_deployment=os.getenv("AZURE_OPENAI_LLM_MODEL"),
    api_version="2024-07-01-preview",
    temperature=0,
)

# Step 6: Prompt Template
prompt = ChatPromptTemplate.from_messages([
    ("system", "You are a helpful Walmart support assistant. Use the provided information to answer product and policy questions. Always cite the retrieved info in your answer."),
    ("human", "{context}\n\nUser question: {question}")
])

# Step 7: Define Nodes
def retrieve_node(state: RAGState) -> RAGState:
    """Retrieve relevant documents"""
    docs = retriever.invoke(state["question"])
    context = "\n".join([doc.page_content for doc in docs])
    return {**state, "context": context}

def generate_node(state: RAGState) -> RAGState:
    """Generate answer using LLM"""
    formatted_prompt = prompt.format(
        context=state["context"], 
        question=state["question"]
    )
    answer = llm.invoke(formatted_prompt)
    return {**state, "answer": answer.content}

# Step 8: Build LangGraph
print("🏗️  Building RAG graph...")
builder = StateGraph(RAGState)

builder.add_node("retrieve", retrieve_node)
builder.add_node("generate", generate_node)

builder.set_entry_point("retrieve")
builder.add_edge("retrieve", "generate")
builder.set_finish_point("generate")

rag_graph = builder.compile()
print("✓ RAG graph compiled")
print()

# Step 9: Test with sample question
print("=" * 80)
print("TESTING RAG CHATBOT")
print("=" * 80)
print()

user_question = "Can I return an opened Amazon Kindle?"

print(f"👤 User Question: {user_question}")
print()

result = rag_graph.invoke({"question": user_question})

print(f"📖 Retrieved Context:\n{result['context']}")
print()
print(f"🤖 Generated Answer:\n{result['answer']}")
print()

# Save output
output_lines = []
output_lines.append("=" * 80)
output_lines.append("WALMART RAG CHATBOT - Q&A LOG")
output_lines.append("Assignment 14")
output_lines.append("=" * 80)
output_lines.append("")
output_lines.append(f"User Question: {user_question}")
output_lines.append("")
output_lines.append(f"Retrieved Context:")
output_lines.append(result['context'])
output_lines.append("")
output_lines.append(f"Generated Answer:")
output_lines.append(result['answer'])
output_lines.append("")
output_lines.append("=" * 80)

output_file = "output.txt"
with open(output_file, 'w', encoding='utf-8') as f:
    f.write('\n'.join(output_lines))

print(f"✓ Results saved to: {output_file}")

# Summary
print()
print("=" * 80)
print("SUMMARY")
print("=" * 80)
print(f"Total policy documents: {len(docs)}")
print(f"Vector store: FAISS")
print(f"Embedding model: {os.getenv('AZURE_OPENAI_EMBED_MODEL')}")
print(f"LLM model: {os.getenv('AZURE_OPENAI_LLM_MODEL')}")
print(f"Graph nodes: retrieve, generate")
print()
print("✓ RAG chatbot demonstration complete!")
print()
print("💡 Reflection: RAG improves retail support by:")
print("   • Handling natural language questions (not just keywords)")
print("   • Combining multiple policy documents for comprehensive answers")
print("   • Easy to scale - add new policies without rewriting FAQs")
print("   • Cites source documents, reducing misinformation")
print("   • Instant answers vs manual search through manuals")
